// 首次安装引导页：按浏览器语言填文案（MV3 的 CSP 不允许内联脚本，所以独立成文件）
// 与工作台一致的规则：用户手动选过语言就用它，否则跟浏览器
const DICT = self.__I18N_DICT || {};
const saved = localStorage.getItem("lang");
const ui = saved && DICT[saved] ? saved
  : (/^zh/i.test((chrome.i18n && chrome.i18n.getUILanguage && chrome.i18n.getUILanguage()) || "") ? "zh_CN" : "en");

document.querySelectorAll("[data-i18n]").forEach((el) => {
  const key = el.dataset.i18n;
  const msg = (DICT[ui] && DICT[ui][key]) || (chrome.i18n && chrome.i18n.getMessage(key));
  if (msg) el.textContent = msg;
});
document.documentElement.lang = ui === "zh_CN" ? "zh-CN" : "en";

// 手册链接按界面语言切换（英文用户不该被丢到中文文档）
const manual = document.querySelector('a[data-i18n="wManual"]');
if (manual && ui === "en") {
  manual.href = "https://zzehui.github.io/DouDuo/pdfpocket/manual/en/";
}
