// 点工具栏图标 → 打开工作台（扩展的 popup 太小，装不下拖拽和预览）
chrome.action.onClicked.addListener(() => {
  chrome.tabs.create({ url: chrome.runtime.getURL("src/app.html") });
});

chrome.runtime.onInstalled.addListener(({ reason }) => {
  if (reason === "install") {
    chrome.tabs.create({ url: chrome.runtime.getURL("src/welcome.html") });
  }
});
